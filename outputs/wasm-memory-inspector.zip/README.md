# WASM Memory Inspector

Extensão experimental para Chrome/Edge que detecta instâncias de `WebAssembly.Memory`, procura valores numéricos e permite editar endereços encontrados.

> Use somente em páginas próprias, ambientes de laboratório ou aplicações para as quais você tenha autorização. Esta ferramenta não contorna anti-cheat, proteções do navegador ou políticas do site.

## Instalação

1. Abra `chrome://extensions` no Chrome ou `edge://extensions` no Edge.
2. Ative **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação**.
4. Selecione esta pasta: `wasm-memory-inspector`.
5. Abra ou recarregue a página que usa WebAssembly.
6. Clique no ícone da extensão.
7. Clique em **Abrir painel móvel na página**. Arraste-o pelo cabeçalho ou use os quatro botões de alinhamento.

### Atualizando uma instalação anterior

1. Substitua a pasta antiga pelos arquivos desta versão.
2. Abra `chrome://extensions` e clique no botão de **recarregar** do WASM Memory Inspector.
3. Só então recarregue a aba do jogo. Recarregar apenas o jogo não aplica mudanças no manifesto da extensão.

## Uso

1. Selecione uma memória detectada.
2. Escolha o tipo numérico usado pelo aplicativo.
3. Informe o valor atual e clique em **Nova busca**.
4. Mude o valor dentro do aplicativo, informe o novo valor e clique em **Filtrar**.
5. Repita até restarem poucos endereços.
6. Altere um valor na lista e clique em `↵` para gravá-lo.

## Limitações conhecidas

- A extensão precisa estar instalada antes da página ser carregada.
- A extensão observa todos os `iframes`, alocações de `WebAssembly.Memory`, instanciações síncronas e `WebAssembly.instantiate`/`instantiateStreaming`.
- Builds Unity que executam toda a memória dentro de um `Web Worker` isolado podem continuar inacessíveis; o navegador não expõe essa memória ao documento principal.
- Páginas internas (`chrome://`), a Chrome Web Store e arquivos locais sem permissão não são suportados.
- A busca inicial é alinhada ao tamanho do tipo escolhido e mostra no máximo 5.000 resultados.
- Memórias muito grandes podem tornar a busca lenta por alguns segundos.
- Valores de ponto flutuante usam uma pequena tolerância de comparação.

## Estrutura

- `page-hook.js`: observa a criação de instâncias WASM e opera sobre a memória.
- `bridge.js`: encaminha mensagens entre o popup e o contexto da página.
- `popup.*`: interface da extensão.
